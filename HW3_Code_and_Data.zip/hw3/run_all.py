"""DATA 37711 Homework 3. Run from any directory with --smoke or --problem all."""
import argparse  # 명령행에서 실행할 문항을 고른다.
from pathlib import Path  # 파일 경로를 운영체제에 맞게 만든다.
from itertools import product  # 후보값의 모든 조합을 만든다.
import numpy as np  # 벡터와 평균을 계산한다.
import pandas as pd  # CSV 표를 읽고 쓴다.
from sklearn.ensemble import RandomForestRegressor, GradientBoostingClassifier  # 회귀 숲과 분류 부스팅 모델.
from sklearn.neighbors import KNeighborsRegressor  # 가까운 와인의 점수를 이용하는 회귀 모델.
from sklearn.model_selection import train_test_split  # 서로 겹치지 않는 집합으로 나눈다.
from sklearn.preprocessing import StandardScaler  # 훈련 평균과 표준편차로 거리의 단위를 맞춘다.
from sklearn.metrics import mean_squared_error, log_loss, accuracy_score  # 회귀·분류 평가 지표.
from sklearn.tree import DecisionTreeRegressor  # 음의 기울기를 근사할 작은 나무.

ROOT = Path(__file__).resolve().parent  # 스크립트 폴더를 기준으로 입력을 찾는다.
OUT = ROOT / 'results'  # 실행 결과를 저장할 폴더.
OUT.mkdir(exist_ok=True)  # 폴더가 이미 있어도 계속한다.
SEED = 42  # 분할과 모델 난수를 재현한다.

def poisson():  # 1번의 포아송 부스팅 손계산을 함수로 묶는다.
    x = np.arange(4).reshape(-1, 1)  # 설명용 입력 네 개를 한 열로 만든다.
    y = np.array([0, 1, 4, 3])  # 직접 만든 개수 예제.
    score = np.full(4, np.log(y.mean()))  # 초기 평균 2의 로그를 모든 행에 둔다.
    residual = y - np.exp(score)  # 음의 기울기를 계산한다.
    stump = DecisionTreeRegressor(max_depth=1, random_state=SEED).fit(x, residual)  # 한 번 나눠 잔차를 근사한다.
    direction = stump.predict(x)  # 각 행에서 나무의 수정을 읽는다.
    updated = score + 0.1 * direction  # 고정 보폭으로 로그 평균을 갱신한다.
    for name, f in [('initial', score), ('updated', updated)]:  # 갱신 전후를 비교한다.
        print(name, 'mean', np.exp(f), 'loss', np.mean(np.exp(f) - y*f))  # 상수항을 생략한 NLL.

def wine():  # 2번의 분할, 모델 선택, 최종 평가를 순서대로 실행한다.
    df = pd.read_csv(ROOT/'data/winequality-white.csv', sep=None, engine='python')  # 쉼표·세미콜론 구분자를 감지한다.
    x = df.drop(columns='quality').to_numpy()  # 입력은 화학적 측정값이다.
    y = df['quality'].to_numpy()  # 마지막 열의 품질 점수를 예측한다.
    ids = np.arange(len(y))  # 각 행에 고유한 위치 번호를 준다.
    dev, test = train_test_split(ids, test_size=.2, random_state=SEED)  # 테스트 20%를 보관한다.
    tr, va = train_test_split(dev, test_size=.125, random_state=SEED)  # 남은 80% 중 1/8을 검증에 쓴다.
    scaler = StandardScaler().fit(x[tr])  # 거리 계산용 스케일은 훈련 행에서만 추정한다.
    z = scaler.transform(x)  # 모든 행을 동일한 단위로 나타낸다.
    scores, finalists = [], []  # 검증 결과와 모델별 최종 후보를 보관한다.
    for k, weights, p in product(range(1,126), ['uniform','distance'], [1,2]):  # 125×2×2개 설정.
        model = KNeighborsRegressor(n_neighbors=k, weights=weights, p=p, algorithm='kd_tree')  # 이웃 수, 평균에 쓸 가중치, 거리 종류.
        model.fit(z[tr], y[tr])  # 훈련 행을 이웃 후보로 저장한다.
        mse = mean_squared_error(y[va], model.predict(z[va]))  # 검증 예측의 평균제곱오차.
        scores.append(dict(family='KNN', k=k, weights=weights, p=p, val=mse))  # 후보별 결과 기록.
    kn = min(scores, key=lambda row: row['val'])  # 검증 MSE가 가장 작은 KNN을 고른다.
    model = KNeighborsRegressor(n_neighbors=kn['k'], weights=kn['weights'], p=kn['p'], algorithm='kd_tree').fit(z[tr], y[tr])  # 선택된 이웃 수, 가중치, 거리로 훈련 행을 다시 저장한다.
    finalists.append((kn, model, z))  # 같은 훈련 집합으로 선택된 모델을 복원한다.
    for depth, leaf, feat in product([3,5,8,12,18,None], [1,2,4,8,16], [2,4,6,8,11]):  # 150종 나무 규칙.
        forest = RandomForestRegressor(max_depth=depth, min_samples_leaf=leaf, max_features=feat, warm_start=True, random_state=SEED)  # 같은 숲에서 기존 나무를 보존하고 다음 나무를 추가하도록 설정한다.
        for count in [4,8,12,16]:  # 같은 난수열의 나무를 이어 붙여 네 숲 크기를 평가한다.
            forest.set_params(n_estimators=count).fit(x[tr], y[tr])  # 검증 데이터는 학습에 사용하지 않는다.
            mse = mean_squared_error(y[va], forest.predict(x[va]))  # 해당 숲의 검증 오차.
            scores.append(dict(family='RF', depth=depth, leaf=leaf, feat=feat, count=count, val=mse))  # 600개 후보 기록.
    rf = min((r for r in scores if r['family']=='RF'), key=lambda row: row['val'])  # 숲 안에서 한 번 선택한다.
    forest = RandomForestRegressor(n_estimators=rf['count'], max_depth=rf['depth'], min_samples_leaf=rf['leaf'], max_features=rf['feat'], random_state=SEED)  # 검증에서 선택한 네 설정을 새 숲에 넣는다.
    finalists.append((rf, forest.fit(x[tr],y[tr]), x))  # 선택된 숲을 같은 시드로 다시 학습한다.
    pd.DataFrame(scores).to_csv(OUT/'wine_grid.csv', index=False)  # 검증 후보 전체를 저장한다.
    print('wine split', len(tr),len(va),len(test))  # 실제 행 수를 확인한다.
    for row, predictor, inputs in finalists:  # 모델별 선택이 모두 끝난 뒤 테스트한다.
        row['test'] = mean_squared_error(y[test], predictor.predict(inputs[test]))  # 최종 테스트 MSE.
        print(row)  # 선택한 설정과 두 오차를 출력한다.
    pd.DataFrame([kn,rf]).to_csv(OUT/'wine_selected.csv', index=False)  # 보고서의 수치 근거.

def boosting():  # 3번에서 두 표에 같은 부스팅 절차를 적용한다.
    rows = []  # 데이터셋별 오차를 쌓는다.
    for name in ['dset0','dset1']:  # 주어진 두 파일을 각각 평가한다.
        df = pd.read_csv(ROOT/f'data/{name}-1.csv',header=None)  # 첫 행도 관측값으로 읽는다.
        y = df.iloc[:,0].astype(int)  # 첫 열은 이진 정답이다.
        x = df.iloc[:,1:]  # 나머지 다섯 열은 입력이다.
        x_train, x_hold, y_train, y_hold = train_test_split(x,y,test_size=.3,stratify=y,random_state=SEED)  # 350/150, 라벨 비율 유지.
        model = GradientBoostingClassifier(n_estimators=1000,learning_rate=.1,max_depth=1,random_state=SEED).fit(x_train,y_train)  # 350개 훈련 행으로 깊이 1인 나무를 1,000번 더한다.
        stages = zip(model.staged_predict_proba(x_train),model.staged_predict_proba(x_hold))  # t개 나무까지의 확률을 순서대로 읽는다.
        for m,(train_prob,hold_prob) in enumerate(stages,start=1):  # 첫 결과는 트리 하나.
            if m in [1,10,100,300,1000]:  # 지문에서 요구한 다섯 지점만 저장한다.
                row = {'data':name,'trees':m}  # 한 지점의 결과.
                for key,target,prob in [('train',y_train,train_prob),('hold',y_hold,hold_prob)]:  # 같은 공식을 두 집합에 적용한다.
                    row[key+'_loss'] = log_loss(target,prob)  # 정답에 작은 확률을 주면 큰 손실이 생긴다.
                    row[key+'_error'] = 1-accuracy_score(target,model.classes_[prob.argmax(axis=1)])  # 오분류한 비율.
                rows.append(row)  # 결과표에 추가한다.
    table = pd.DataFrame(rows)  # 딕셔너리 목록을 표로 바꾼다.
    table.to_csv(OUT/'boosting.csv',index=False)  # 그래프와 보고서에 쓸 수치를 보관한다.
    print(table.to_string(index=False))  # 행 순서대로 확인한다.

if __name__ == '__main__':  # 이 파일을 직접 실행할 때 아래 명령을 읽는다.
    arg = argparse.ArgumentParser()  # 사용 가능한 명령행 옵션을 정의한다.
    arg.add_argument('--problem',choices=['1','2','3','all'],default='all')  # 문항 번호를 생략하면 세 문항을 모두 실행한다.
    arg.add_argument('--smoke',action='store_true')  # 간단한 데이터·코드 확인용.
    opt = arg.parse_args()  # 사용자가 선택한 옵션을 읽는다.
    if opt.smoke:  # 빠른 점검을 선택했는지 확인한다.
        for filename in ['winequality-white.csv','dset0-1.csv','dset1-1.csv']:  # 확인할 세 입력 파일 이름을 하나씩 읽는다.
            assert (ROOT/'data'/filename).is_file(), filename  # 파일 누락 시 이름을 알려준다.
        poisson()  # 실제 한 번의 학습을 확인한다.
    else:  # 전체 실험이나 개별 문항 실행을 선택한 경우다.
        for number, action in [('1',poisson),('2',wine),('3',boosting)]:  # 문항 번호와 실행할 함수를 짝지어 순회한다.
            if opt.problem in [number,'all']:  # 지정한 문항 또는 전체 실행에 해당하는지 검사한다.
                action()  # 선택한 문항을 실행한다.
