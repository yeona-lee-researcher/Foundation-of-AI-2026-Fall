# DATA 37711 · Homework 3 · Elina Lee

Read [the six-page report](HW3_Elina_Lee.pdf) for the mathematical solutions and results. The [LaTeX source](HW3_Elina_Lee.tex) includes the figure coordinates. The [Korean study companion](Study_KO.pdf) works through the same ideas from the first numerical example to the implementation. The code includes Korean line annotations.

## Reproduce the experiments

From the repository root run `cd hw3`. From the Canvas ZIP, extract the archive and open its `hw3` directory. Both entry points use the included CSVs and the commands below. Python 3.12 was used for the recorded run. The pinned packages also support Python 3.11.

```sh
python -m venv .venv
# macOS/Linux
source .venv/bin/activate
# On Windows PowerShell use .\.venv\Scripts\Activate.ps1 instead.
python -m pip install -r requirements.txt
python run_all.py --smoke
python run_all.py --problem all
```

The smoke check verifies the presence of three inputs and runs one Poisson boosting step. For a single problem use `--problem 1`, `--problem 2`, or `--problem 3`. Problem 2 fits two grids and takes the largest share of the runtime. The script resolves paths relative to itself. Problems 2 and 3 regenerate the CSVs under `results/`. Compare terminal output with [the recorded run](results/run_log.txt).

## Grading checklist

| Part | Report page | Derivation or implementation | Evidence |
|---|---:|---|---|
| 1(a)(i) | 1 | Poisson model for counts and its conditional mean/variance | Equation (1) and following paragraph |
| 1(a)(ii) | 1 | Convert the real-valued tree score to a positive Poisson mean | Paragraph headed “Why exponentiate?” |
| 1(b) | 1 | Negative log-likelihood | Equation (2) |
| 1(c) | 1 | Score derivative and curvature | Equation (3) |
| 1(d) | 2 | Negative gradient, fitted tree, update; `poisson()` | Equations (4)–(6), four-count table, first two lines of the run log |
| 2(a) | 3 | Fixed-candidate concentration and union bound | Boxed bound, assumptions, event for selected model |
| 2(b) | 3 | Expected minimum versus minimum expected risk | Displayed expectation inequality |
| 2(c) | 4 | `wine()` selects 500 KNN and 600 RF settings on validation | [1,100 validation scores](results/wine_grid.csv), [two test results](results/wine_selected.csv), split in run log |
| 3(a) | 5 | `boosting()` on dataset 0 | Five dset0 rows in [boosting.csv](results/boosting.csv) |
| 3(b) | 5 | Same experiment on dataset 1 | Five dset1 rows in the same CSV |
| 3(c) | 6 | Compare held-out loss and label error | Learning curves, 300-to-1,000 changes, interpretation |

The forest depth field is empty for an unrestricted depth (`None`). Hyperparameter fields that belong to the other model family are also empty. The reported wine MSEs refer to two representatives selected on validation with training membership fixed. The two curves in Problem 3 reuse each dataset's held-out split for all five checkpoints. A new test set would be needed for a final independent evaluation after selecting a checkpoint on these curves.

## Data

- Problem 1 uses four illustrative counts defined inside the script.
- Problem 2 uses the original white subset of Wine Quality, 4,898 rows, 11 predictors. P. Cortez, A. Cerdeira, F. Almeida, T. Matos and J. Reis (2009), UCI Machine Learning Repository. [Dataset and CC BY 4.0 license](https://archive.ics.uci.edu/dataset/186/wine+quality) · [DOI](https://doi.org/10.24432/C56S3T). The included semicolon-delimited CSV is unmodified. SHA-256 is `76c3f809815c17c07212622f776311faeb31e87610d52c26d87d6e361b169836`. The course file `winequality-white-1.csv` matches the included file byte for byte.
- Problem 3 uses the supplied `dset0-1.csv` and `dset1-1.csv`, each with 500 observations. The first column is a 0/1 label and the other five columns are features. There is no header row.

## Rebuild the documents

Use XeLaTeX with standard TeX Live packages, including PGFPlots. Run each command twice. The Korean guide additionally uses the system fonts Noto Serif CJK KR and Noto Sans Mono CJK KR.

```sh
xelatex HW3_Elina_Lee.tex
xelatex Study_KO.tex
```
